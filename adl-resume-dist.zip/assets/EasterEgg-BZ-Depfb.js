import{M as I,d as f,q as E,y as M,u as t}from"./vendor-preact-B8qmTIR6.js";import{c as C}from"./index-GOfZOYCl.js";const h=["ArrowUp","ArrowUp","ArrowDown","ArrowDown","ArrowLeft","ArrowRight","ArrowLeft","ArrowRight"],q="اآبپتثجچحخدذرزسشصضطظعغفقکگلمنوهی۱۲۳۴۵۶۷۸۹۰",O=I(function(){const[c,x]=f(!1),[b,w]=f([]),[R,y]=f([]),[u,v]=f(!1),[p,N]=f(0),A=()=>q[Math.floor(Math.random()*q.length)],T=E(e=>{const a=Math.floor(Math.random()*15)+8;return{id:e,x:Math.random()*100,chars:Array.from({length:a},A),speed:Math.random()*1.5+.5,opacity:Math.random()*.5+.5}},[]),k=E(()=>{try{const e=new(window.AudioContext||window.webkitAudioContext);[220,261.63,329.63,392,493.88,587.33].forEach((s,g)=>{const d=e.createOscillator(),m=e.createGain();d.type=g<3?"sine":"triangle",d.frequency.setValueAtTime(s,e.currentTime),m.gain.setValueAtTime(0,e.currentTime),m.gain.linearRampToValueAtTime(.12,e.currentTime+.05+g*.04),m.gain.exponentialRampToValueAtTime(.001,e.currentTime+2.5),d.connect(m),m.connect(e.destination),d.start(e.currentTime+g*.04),d.stop(e.currentTime+2.5)});const n=e.createBufferSource(),r=e.createBuffer(1,e.sampleRate*.5,e.sampleRate),o=r.getChannelData(0);for(let s=0;s<o.length;s++)o[s]=(Math.random()*2-1)*.3;n.buffer=r;const i=e.createGain(),l=e.createBiquadFilter();l.type="highpass",l.frequency.setValueAtTime(2e3,e.currentTime),l.frequency.exponentialRampToValueAtTime(8e3,e.currentTime+.3),i.gain.setValueAtTime(.08,e.currentTime),i.gain.exponentialRampToValueAtTime(.001,e.currentTime+.4),n.connect(l),l.connect(i),i.connect(e.destination),n.start()}catch{}},[]);M(()=>{const e=a=>{if(a.target instanceof HTMLInputElement||a.target instanceof HTMLTextAreaElement)return;const n=a.code,r=[...b,n].slice(-h.length);w(r);let o=0;for(let i=0;i<r.length&&r[i]===h[i];i++)o++;if(N(o),r.join(",")===h.join(",")){x(!0),w([]),N(0),k();const i=Array.from({length:60},(l,s)=>T(s));y(i),setTimeout(()=>x(!1),12e3)}r.length>=2&&r.slice(-2).join(",")==="ArrowUp,ArrowUp"&&o>=2&&(v(!0),setTimeout(()=>v(!1),4e3))};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[b,T,k]),M(()=>{if(!c)return;const e=setInterval(()=>{y(a=>a.map(n=>{if(Math.random()<.1){const r=[...n.chars],o=Math.floor(Math.random()*r.length);return r[o]=A(),{...n,chars:r}}return n}))},80);return()=>clearInterval(e)},[c]);const D=()=>{x(!1)};return!c&&!u&&p===0?null:!c&&!u&&p>0?t("div",{className:"fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] animate-in fade-in duration-200",children:t("div",{className:"flex items-center gap-1.5 px-4 py-2 rounded-full bg-card/90 backdrop-blur-md border border-border/50 shadow-lg",children:[h.map((e,a)=>t("div",{className:C("w-2 h-2 rounded-full transition-all duration-200",a<p?"bg-green-500 scale-110":"bg-muted-foreground/30")},a)),p>=h.length-2&&t("span",{className:"text-xs text-green-400 ml-2 animate-pulse",children:"Almost there!"})]})}):u&&!c?t("div",{className:"fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] animate-in fade-in slide-in-from-bottom-4 duration-300",children:t("div",{className:"px-5 py-3 rounded-2xl bg-card/95 backdrop-blur-xl border border-primary/30 shadow-2xl shadow-primary/10",children:t("p",{className:"text-sm text-foreground flex items-center gap-2",children:[t("span",{className:"text-lg",children:"🎮"}),t("span",{className:"text-primary font-mono font-bold",children:"↑↑↓↓←→←→"}),t("span",{className:"text-muted-foreground",children:"for a surprise..."})]})})}):t("div",{className:"fixed inset-0 z-[200] bg-black cursor-pointer overflow-hidden",onClick:D,children:[t("div",{className:"absolute inset-0 overflow-hidden font-mono text-sm",children:R.map(e=>t("div",{className:"absolute top-0 flex flex-col",style:{left:`${e.x}%`,animation:`matrix-fall ${18/e.speed}s linear infinite`,opacity:e.opacity},children:e.chars.map((a,n)=>t("span",{className:C("leading-tight",n===0&&"text-white font-bold text-base",n===1&&"text-green-300",n>1&&n<4&&"text-green-400",n>=4&&"text-green-500",n>e.chars.length-3&&"text-green-800"),style:{textShadow:n===0?"0 0 10px #fff, 0 0 20px #0f0, 0 0 30px #0f0":n<3?"0 0 8px #0f0":void 0},children:a},n))},e.id))}),t("div",{className:"absolute inset-0 flex items-center justify-center p-4",children:t("div",{className:"text-center animate-in zoom-in-75 fade-in duration-700 max-w-lg",children:[t("div",{className:"absolute inset-0 -z-10 bg-gradient-to-r from-green-500/20 via-transparent to-green-500/20 blur-3xl"}),t("h2",{className:"text-4xl md:text-6xl font-bold text-green-400 mb-4 glitch-text tracking-wider","data-text":"WELCOME NEO",children:"WELCOME NEO"}),t("p",{className:"text-green-400/90 text-lg md:text-xl mb-6 font-light",children:"You've proven you're not an ordinary visitor..."}),t("div",{className:"inline-flex items-center gap-4 mb-8 px-6 py-3 rounded-xl bg-black/50 backdrop-blur-sm border border-green-500/30",children:[t("div",{className:"flex flex-col items-center",children:[t("span",{className:"text-3xl mb-1",children:"🐰"}),t("span",{className:"text-green-500 text-xs",children:"Follow"})]}),t("div",{className:"w-px h-12 bg-green-500/30"}),t("div",{className:"text-left",children:[t("p",{className:"text-green-400 text-sm",children:"The rabbit hole goes deeper..."}),t("p",{className:"text-green-600 text-xs mt-1",children:"Check the terminal section"})]})]}),t("p",{className:"text-green-600/80 text-sm animate-pulse",children:"Click anywhere to return to the simulation"})]})}),t("div",{className:"absolute inset-0 pointer-events-none opacity-[0.03]",style:{background:"repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,0,0.1) 2px, rgba(0,255,0,0.1) 4px)"}}),t("div",{className:"absolute inset-0 pointer-events-none",style:{background:"radial-gradient(circle at 50% 50%, transparent 30%, rgba(0,0,0,0.5) 100%)"}}),t("style",{children:`
        @keyframes matrix-fall {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100vh); }
        }
        
        .glitch-text {
          position: relative;
          animation: text-flicker 4s linear infinite;
        }
        
        .glitch-text::before,
        .glitch-text::after {
          content: attr(data-text);
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }
        
        .glitch-text::before {
          animation: glitch-1 0.3s infinite linear alternate-reverse;
          clip-path: polygon(0 0, 100% 0, 100% 35%, 0 35%);
          color: #0ff;
          text-shadow: -2px 0 #0ff;
        }
        
        .glitch-text::after {
          animation: glitch-2 0.3s infinite linear alternate-reverse;
          clip-path: polygon(0 65%, 100% 65%, 100% 100%, 0 100%);
          color: #f0f;
          text-shadow: 2px 0 #f0f;
        }
        
        @keyframes glitch-1 {
          0% { transform: translateX(-2px); }
          100% { transform: translateX(2px); }
        }
        
        @keyframes glitch-2 {
          0% { transform: translateX(2px); }
          100% { transform: translateX(-2px); }
        }
        
        @keyframes text-flicker {
          0%, 100% { opacity: 1; }
          92% { opacity: 1; }
          93% { opacity: 0.8; }
          94% { opacity: 1; }
          95% { opacity: 0.9; }
          96% { opacity: 1; }
        }
      `})]})});function z(){}export{O as EasterEgg,z as initDevToolsEasterEgg};
